<?php

namespace App\Exceptions;

class ApiClientHasInvalidTokenException extends \Exception
{

}
