<?php

namespace App\Exceptions;

class ApiClientTokenExpiredException extends \Exception
{

}
