<?php

namespace App\Exceptions;

class UnsupportedSite extends \Exception
{

}
