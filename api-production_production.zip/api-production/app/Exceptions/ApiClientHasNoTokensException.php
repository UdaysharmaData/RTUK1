<?php

namespace App\Exceptions;

class ApiClientHasNoTokensException extends \Exception
{

}
