<?php

namespace App\Exceptions;

class MailException extends \Exception
{

}
