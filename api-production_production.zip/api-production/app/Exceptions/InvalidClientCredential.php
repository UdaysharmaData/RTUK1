<?php

namespace App\Exceptions;

class InvalidClientCredential extends \Exception
{

}
