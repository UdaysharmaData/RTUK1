<?php

namespace App\Exceptions;

class SiteNotFound extends \Exception
{

}
