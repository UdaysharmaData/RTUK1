<?php

namespace App\Exceptions;

class ApiClientTokenRevokedException extends \Exception
{

}
