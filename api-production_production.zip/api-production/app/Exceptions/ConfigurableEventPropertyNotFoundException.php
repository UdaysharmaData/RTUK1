<?php

namespace App\Exceptions;

class ConfigurableEventPropertyNotFoundException extends \Exception
{

}
