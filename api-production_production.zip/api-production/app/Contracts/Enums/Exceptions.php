<?php

namespace App\Contracts\Enums;

interface Exceptions
{
    /**
     * @return array
     */
    public static function exceptions() :array;
}
