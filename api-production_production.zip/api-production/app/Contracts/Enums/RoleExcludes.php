<?php

namespace App\Contracts\Enums;

interface RoleExcludes
{
    /**
     * @return array
     */
    public static function roleExcludes() :array;
}
