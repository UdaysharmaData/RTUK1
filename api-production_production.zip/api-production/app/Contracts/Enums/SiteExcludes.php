<?php

namespace App\Contracts\Enums;

interface SiteExcludes
{
    /**
     * @return array
     */
    public static function siteExcludes() :array;
}
