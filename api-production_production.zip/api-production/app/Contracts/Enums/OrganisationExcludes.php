<?php

namespace App\Contracts\Enums;

interface OrganisationExcludes
{
    /**
     * @return array
     */
    public static function organisationExcludes() :array;
}
