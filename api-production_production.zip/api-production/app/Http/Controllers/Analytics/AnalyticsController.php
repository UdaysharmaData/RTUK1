<?php

namespace App\Http\Controllers\Analytics;

class AnalyticsController
{
    public function __construct(protected string $action) {}
}
